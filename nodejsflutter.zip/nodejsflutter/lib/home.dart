import 'package:flutter/material.dart';
import 'package:nodejsflutter/create_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  const Color.fromARGB(255, 3, 13, 67),
                  const Color.fromARGB(255, 7, 49, 68),
                ]), // // LinearGradient
              ), // // BoxDecoration
            ), // // Container
            Container(
              margin: EdgeInsets.symmetric(horizontal: 50.0, vertical: 100.0),
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 237, 247, 252),
                borderRadius: BorderRadius.circular(14.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.lightBlue,
                    offset: Offset(3.0, 5.0),
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ), // // BoxShadow
                ], // // BoxDecoration
              ), // // Container
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CreatePage(),
                            ),
                          );
                        },
                        label: Text("Create"),
                        icon: Icon(Icons.add),
                      ), // // ElevatedButton.icon
                    ), // // Padding
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        onPressed: () {},
                        label: Text("Read"),
                        icon: Icon(Icons.read_more_rounded),
                      ), // // ElevatedButton.icon
                    ), // // Padding
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        onPressed: () {},
                        label: Text("Update"),
                        icon: Icon(Icons.update),
                      ), // // ElevatedButton.icon
                    ), // // Padding
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        onPressed: () {},
                        label: Text("Delete"),
                        icon: Icon(Icons.delete),
                      ), // // ElevatedButton.icon
                    ), // // Padding
                  ], // // Column children
                ), // // Column
              ), // // Center
            ), // // Container
          ], // // Stack children
        ), // // Stack
      ), // // Container
    ); // // Scaffold
  }
}