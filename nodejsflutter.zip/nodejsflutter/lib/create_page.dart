import 'package:flutter/material.dart';

class CreatePage extends StatefulWidget {
  const CreatePage({super.key});

  @override
  State<CreatePage> createState() => _CreatePageState();
}

class _CreatePageState extends State<CreatePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  const Color.fromARGB(255, 3, 13, 67),
                  const Color.fromARGB(255, 7, 49, 68),
                ]), // // LinearGradient
              ), // // BoxDecoration
            ), // // Container
            Container(
              margin: EdgeInsets.symmetric(horizontal: 50.0, vertical: 100.0),
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 237, 247, 252),
                borderRadius: BorderRadius.circular(14.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.lightBlue,
                    offset: Offset(3.0, 5.0),
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ), // // BoxShadow
                ], // // BoxShadow
              ), // // BoxDecoration
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Register Form",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 30.0,
                      ),
                    ),
                    Divider(
                      indent: 70.0,
                      endIndent: 60.0,
                      color: const Color.fromARGB(255, 1, 47, 68),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 50.0,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: "Username",
                            labelStyle: TextStyle(color: Colors.blue),
                            prefixIcon: Icon(
                              Icons.account_circle_sharp,
                              color: const Color.fromARGB(255, 4, 31, 53),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14.0),
                            ), // // OutlineInputBorder
                          ), // // InputDecoration
                        ), // // TextFormField
                      ), // // Padding
                    ), // // Container
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 50.0,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: "Email",
                            labelStyle: TextStyle(color: Colors.blue),
                            prefixIcon: Icon(
                              Icons.email,
                              color: const Color.fromARGB(255, 4, 31, 53),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14.0),
                            ), // // OutlineInputBorder
                          ), // // InputDecoration
                        ), // // TextFormField
                      ), // // Padding
                    ), // // Container
                    Container(
                      margin: EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 50.0,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: "Phone no",
                            labelStyle: TextStyle(color: Colors.blue),
                            prefixIcon: Icon(
                              Icons.phone,
                              color: const Color.fromARGB(255, 4, 31, 53),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14.0),
                            ), // // OutlineInputBorder
                          ), // // InputDecoration
                        ), // // TextFormField
                      ), // // Padding
                    ), // // Container
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ElevatedButton.icon(
                        onPressed: () {},
                        label: Text("Register"),
                        icon: Icon(Icons.app_registration_rounded),
                      ), // // ElevatedButton.icon
                    ), // // Padding
                  ], // // Column children
                ), // // Column
              ), // // Center
            ), // // Container
          ], // // Stack children
        ), // // Stack
      ), // // Container
    ); // // Scaffold
  }
}
