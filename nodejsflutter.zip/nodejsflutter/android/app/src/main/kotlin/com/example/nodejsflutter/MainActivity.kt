package com.example.nodejsflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
